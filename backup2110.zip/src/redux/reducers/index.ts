import { combineReducers } from "redux";
import user from "../../pages/SignIn/redux/reducers/user";

export default combineReducers({
  user,
});
